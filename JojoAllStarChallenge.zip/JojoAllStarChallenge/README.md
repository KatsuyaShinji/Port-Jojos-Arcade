# Jojo's All Star Challenge (Android)
Frontend libretro (core FBNeo) com botões na tela, tela esticada e ROM guardada no app.
1. Suba esta pasta no GitHub (ex.: repo Mk2, apagando os arquivos antigos).
2. Aba Actions -> "Build APK" roda sozinho -> baixe o artifact `JojoAllStarChallenge-apk`.
3. Instale, abra, escolha o zip da ROM uma vez. Depois pode apagar o zip dos Downloads.
Não coloque a ROM no repositório.
