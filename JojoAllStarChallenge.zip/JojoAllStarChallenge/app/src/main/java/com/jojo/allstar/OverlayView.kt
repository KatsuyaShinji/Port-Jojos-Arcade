package com.jojo.allstar

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    // ids do retropad
    companion object {
        const val B = 0; const val Y = 1; const val SELECT = 2; const val START = 3
        const val UP = 4; const val DOWN = 5; const val LEFT = 6; const val RIGHT = 7
        const val A = 8; const val X = 9; const val L = 10; const val R = 11
        const val OPTION = 100; const val EXIT = 101
    }

    class Btn(val id: Int, val bmp: Bitmap, val oval: Boolean) {
        var cx = 0f; var cy = 0f; var w = 0f; var h = 0f; var down = false
        fun hit(x: Float, y: Float): Boolean {
            val dx = (x - cx) / (w / 2f * 1.08f); val dy = (y - cy) / (h / 2f * 1.15f)
            return if (oval) dx * dx + dy * dy <= 1f else Math.abs(dx) <= 1f && Math.abs(dy) <= 1.1f
        }
    }

    var onOption: (() -> Unit)? = null
    var onExit: (() -> Unit)? = null

    private fun load(n: String): Bitmap = ctx.assets.open("$n.png").use { BitmapFactory.decodeStream(it) }
    private val ctx = ctx
    private val analogBmp = load("analog")
    private val btns = listOf(
        Btn(L, load("L"), true), Btn(R, load("R"), true),
        Btn(Y, load("Y"), true), Btn(X, load("X"), true),
        Btn(B, load("B"), true), Btn(A, load("A"), true),
        Btn(EXIT, load("pill_exit"), false), Btn(SELECT, load("pill_coin"), false),
        Btn(OPTION, load("pill_option"), false), Btn(START, load("pill_start"), false)
    )
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private var ax = 0f; private var ay = 0f; private var ar = 0f
    private var knobX = 0f; private var knobY = 0f
    private var analogPtr = -1
    private var dirMask = 0
    private var btnMask = 0
    private val knobBmp: Bitmap by lazy {
        val s = analogBmp.width; val c = s * 0.5f; val r = s * 0.225f
        val out = Bitmap.createBitmap((r * 2).toInt(), (r * 2).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(out); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        cv.drawCircle(r, r, r, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        cv.drawBitmap(analogBmp, -(c - r), -(analogBmp.height * 0.5f - r) , p)
        out
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val H = h.toFloat(); val W = w.toFloat()
        val m = H * 0.05f
        // analogico (embaixo à esquerda)
        val d = H * 0.55f; ar = d / 2f; ax = m * 1.6f + ar; ay = H - m - ar
        // botões de ataque (embaixo à direita) - grade 2x3 do jeito da sua arte
        val bw = H * 0.20f
        val rowH = bw * 0.70f
        val gx = W - m * 1.4f - bw * 0.5f
        val colGap = bw * 1.0f
        val baseY = H - m - rowH * 0.5f
        val place = { b: Btn, col: Int, row: Int, shift: Float ->
            b.w = bw; b.h = bw * b.bmp.height / b.bmp.width
            b.cx = gx - (1 - col) * colGap + shift
            b.cy = baseY - (2 - row) * rowH * 1.02f
        }
        // L R / Y X / B A
        for (i in 0..5) place(btns[i], i % 2, i / 2, when (i / 2) { 0 -> bw * 0.08f; 1 -> -bw * 0.10f; else -> 0f })
        // botões de sistema
        val pw = H * 0.19f
        for (b in btns.drop(6)) { b.w = pw; b.h = pw * b.bmp.height / b.bmp.width }
        btns[6].cx = m + pw / 2; btns[6].cy = H * 0.20f      // EXIT
        btns[7].cx = m + pw / 2; btns[7].cy = H * 0.20f + pw * 0.5f   // COIN
        btns[8].cx = W - m - pw / 2; btns[8].cy = H * 0.20f   // OPTION
        btns[9].cx = W - m - pw / 2; btns[9].cy = H * 0.20f + pw * 0.5f // START
        knobX = ax; knobY = ay
    }

    override fun onDraw(c: Canvas) {
        val s = ar * 2f
        c.drawBitmap(analogBmp, null, RectF(ax - ar, ay - ar * analogBmp.height / analogBmp.width, ax + ar, ay + ar * analogBmp.height / analogBmp.width), paint)
        val kr = ar * 0.45f
        paint.alpha = 255
        c.drawBitmap(knobBmp, null, RectF(knobX - kr, knobY - kr, knobX + kr, knobY + kr), paint)
        for (b in btns) {
            paint.alpha = if (b.down) 255 else 205
            val sc = if (b.down) 0.93f else 1f
            val hw = b.w / 2 * sc; val hh = b.h / 2 * sc
            c.drawBitmap(b.bmp, null, RectF(b.cx - hw, b.cy - hh, b.cx + hw, b.cy + hh), paint)
        }
        paint.alpha = 255
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        val upIdx = if (act == MotionEvent.ACTION_POINTER_UP) e.actionIndex else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) -2 else -1
        val wasDown = btns.map { it.down }
        for (b in btns) b.down = false
        var foundAnalog = false
        var mask = 0
        for (i in 0 until e.pointerCount) {
            if (i == upIdx || upIdx == -2) continue
            val x = e.getX(i); val y = e.getY(i); val id = e.getPointerId(i)
            if (id == analogPtr || (analogPtr == -1 && Math.hypot((x - ax).toDouble(), (y - ay).toDouble()) <= ar * 1.25)) {
                analogPtr = id; foundAnalog = true
                var dx = x - ax; var dy = y - ay
                val lim = ar * 0.55f
                val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (dist > lim) { dx *= lim / dist; dy *= lim / dist }
                knobX = ax + dx; knobY = ay + dy
                val t = lim * 0.45f
                if (dx < -t) mask = mask or (1 shl LEFT)
                if (dx > t) mask = mask or (1 shl RIGHT)
                if (dy < -t) mask = mask or (1 shl UP)
                if (dy > t) mask = mask or (1 shl DOWN)
                continue
            }
            for (b in btns) if (b.hit(x, y)) {
                b.down = true
                if (b.id < 100) mask = mask or (1 shl b.id)
            }
        }
        if (!foundAnalog) { analogPtr = -1; knobX = ax; knobY = ay }
        for ((i, b) in btns.withIndex()) if (b.down && !wasDown[i]) {
            performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
            if (b.id == OPTION) onOption?.invoke()
            if (b.id == EXIT) onExit?.invoke()
        }
        Native.setInput(mask)
        invalidate()
        return true
    }

    fun clearInput() { for (b in btns) b.down = false; analogPtr = -1; knobX = ax; knobY = ay; Native.setInput(0); invalidate() }
}
