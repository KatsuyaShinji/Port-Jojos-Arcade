package com.jojo.allstar

import android.view.Surface

object Native {
    init { System.loadLibrary("jojo_bridge") }
    external fun loadCore(corePath: String, sysDir: String, saveDir: String): Boolean
    external fun loadGame(path: String): Boolean
    external fun sampleRate(): Int
    external fun setSurface(surface: Surface?)
    external fun setInput(mask: Int)
    external fun runFrame(audio: ShortArray): Int
    external fun reset()
    external fun unload()
    external fun lastLog(): String
    external fun clearLog()
}
